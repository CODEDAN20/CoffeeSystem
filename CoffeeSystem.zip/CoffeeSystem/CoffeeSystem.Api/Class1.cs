﻿namespace CoffeeSystem.Api
{
    public class Class1
    {

    }
}
