﻿namespace CoffeeSystem.Domain
{
    public class Class1
    {

    }
}
