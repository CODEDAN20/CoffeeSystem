﻿using Microsoft.AspNetCore.Mvc;
using CoffeeSystem.Domain.Entities;
using CoffeeSystem.Infrastructure.Repositories;
using CoffeeSystem.Infrastructure.Interfaces;

namespace CoffeeSystem.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderProductsController : ControllerBase
    {
        private readonly IOrderProductsRepository _orderProductsRepository;

        public OrderProductsController(IOrderProductsRepository orderProductsRepository)
        {
            _orderProductsRepository = orderProductsRepository;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var orderProducts = _orderProductsRepository.GetAll();
            return Ok(orderProducts);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var orderProducts = _orderProductsRepository.GetById(id);
            if (orderProducts == null)
            {
                return NotFound();
            }
            return Ok(orderProducts);
        }

        [HttpPost]
        public IActionResult Create(OrderProducts orderProducts)
        {
            _orderProductsRepository.Add(orderProducts);
            return CreatedAtAction(nameof(GetById), new { id = orderProducts.Id }, orderProducts);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, OrderProducts orderProducts)
        {
            if (id != orderProducts.Id)
            {
                return BadRequest();
            }

            _orderProductsRepository.Update(orderProducts);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var orderProducts = _orderProductsRepository.GetById(id);
            if (orderProducts == null)
            {
                return NotFound();
            }

            _orderProductsRepository.Delete(orderProducts);
            return NoContent();
        }
    }
}
