﻿using Microsoft.AspNetCore.Mvc;
using CoffeeSystem.Domain.Entities;
using CoffeeSystem.Infrastructure.Repositories;
using CoffeeSystem.Infrastructure.Interfaces;

namespace CoffeeSystem.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrdersRepository _ordersRepository;

        public OrdersController(IOrdersRepository ordersRepository)
        {
            _ordersRepository = ordersRepository;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var orders = _ordersRepository.GetAll();
            return Ok(orders);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var orders = _ordersRepository.GetById(id);
            if (orders == null)
            {
                return NotFound();
            }
            return Ok(orders);
        }

        [HttpPost]
        public IActionResult Create(Orders orders)
        {
            _ordersRepository.Add(orders);
            return CreatedAtAction(nameof(GetById), new { id = orders.Id }, orders);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Orders orders)
        {
            if (id != orders.Id)
            {
                return BadRequest();
            }

            _ordersRepository.Update(orders);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var orders = _ordersRepository.GetById(id);
            if (orders == null)
            {
                return NotFound();
            }

            _ordersRepository.Delete(orders);
            return NoContent();
        }
    }
}
