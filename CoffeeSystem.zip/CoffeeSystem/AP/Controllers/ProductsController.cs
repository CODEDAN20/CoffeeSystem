﻿using Microsoft.AspNetCore.Mvc;
using CoffeeSystem.Domain.Entities;
using CoffeeSystem.Infrastructure.Repositories;

namespace CoffeeSystem.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductsRepository _productsRepository;

        public ProductsController(IProductsRepository productsRepository)
        {
            _productsRepository = productsRepository;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var products = _productsRepository.GetAll();
            return Ok(products);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var products = _productsRepository.GetById(id);
            if (products == null)
            {
                return NotFound();
            }
            return Ok(products);
        }

        [HttpPost]
        public IActionResult Create(Products products)
        {
            _productsRepository.Add(products);
            return CreatedAtAction(nameof(GetById), new { id = products.Id }, products);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Products products)
        {
            if (id != products.Id)
            {
                return BadRequest();
            }

            _productsRepository.Update(products);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var products = _productsRepository.GetById(id);
            if (products == null)
            {
                return NotFound();
            }

            _productsRepository.Delete(products);
            return NoContent();
        }
    }
}
