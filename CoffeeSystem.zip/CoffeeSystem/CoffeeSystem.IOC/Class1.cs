﻿namespace CoffeeSystem.IOC
{
    public class Class1
    {

    }
}
