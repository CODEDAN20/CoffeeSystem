﻿namespace CoffeeSystem.Infraestructure
{
    public class Class1
    {

    }
}
