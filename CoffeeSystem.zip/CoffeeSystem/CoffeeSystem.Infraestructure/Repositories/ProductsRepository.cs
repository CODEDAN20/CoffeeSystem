﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoffeeSystem.Infrastructure.Interfaces;
using CoffeeSystem.Domain;
using CoffeeSystem.Domain.Entities;

namespace CoffeeSystem.Infrastructure.Repositories
{
    internal class ProductsRepository
    {
    }
}
